

public class UserDoesNotExistException extends Exception {

}
